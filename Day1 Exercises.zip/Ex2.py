#!/usr/bin/env python

from obspy.clients.fdsn import Client
from obspy.geodetics import gps2dist_azimuth
from obspy.core import Stream, UTCDateTime
from pylab import *

#function to retrieve coordinates from input file
def get_coords(infile,station):
	"""
	"""
	infl = open(infile,'r')
	data = infl.readlines()
	infl.close()
	
	for k in data:
		if k.split(None)[0] == station:
			lat = float(k.split(None)[1])
			lon = float(k.split(None)[2])
			break
	return lat,lon

#earthquake location
loc_eq = (-32.115,-71.175)

client1 = Client('iris')

#define station list
stations = ['AC04','AC05','BI02','BI05','BO02','BO03','BO04','CO01','CO02','CO04','CO06','ML02','MT01','MT04','MT07','MT08','MT10','MT13','MT16','VA01','VA03','VA05']

#set empty stream, define times
st = Stream()
t1 = UTCDateTime(2017,1,1,18,03,00)
t2 = UTCDateTime(2017,1,1,18,04,30)

#loop over all stations
for j in stations:
	try:
		#download data and get station coordinates
		data = client1.get_waveforms('C1',j,'--','HHZ',t1,t2)	
		lat, lon = get_coords('coordinates.txt',j)
	except: #in case there is no data, don't give error but continue
		print 'No data found for station: '+j
		continue
	#calculate distance between earthquake and station
	dist = gps2dist_azimuth(lat,lon,loc_eq[0],loc_eq[1])[0]
	data[0].stats.distance = dist
	#add data to stream
	st.append(data[0])

#filter traces and plot record section
st.filter('bandpass',freqmin=0.5,freqmax=5.,corners=2)
st.plot(type='section',outfile='recsec.pdf')
