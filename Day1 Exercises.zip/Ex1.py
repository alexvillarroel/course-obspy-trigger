#!/usr/bin/env python

from obspy.clients.fdsn import Client
from obspy.core import UTCDateTime
from pylab import *
from copy import deepcopy as cp

time_window = 1 #choose 1 or 2 for the two different examples in the exercise

client1 = Client('iris')

if time_window == 1:
  t1 = UTCDateTime(2017,1,1,18,3,0)
  t2 = UTCDateTime(2017,1,1,18,5,0)
elif time_window == 2:
  t1 = UTCDateTime(2017,4,24,4,47,0)
  t2 = UTCDateTime(2017,4,24,4,52,0)



#download data
data = client1.get_waveforms('C1','VA05','--','HHZ',t1,t2)

#data.write('Ex1_data1.mseed',format='MSEED')

#define figure
fig = figure()
ax = fig.add_subplot(1,1,1)

#make 6 copies
dat1 = cp(data)
dat2 = cp(data)
dat3 = cp(data)
dat4 = cp(data)
dat5 = cp(data)
dat6 = cp(data)

#each copy is filtered differently; normalization of amplitudes
dat1[0].data = array(dat1[0].data,dtype='float')
dat1[0].data /= (dat1[0].data).max()

dat2.filter('highpass',freq=1.,corners=2)
dat2[0].data /= dat2[0].data.max()

dat3.filter('lowpass',freq=1.,corners=2)
dat3[0].data /= dat3[0].data.max()

dat4.filter('bandpass',freqmin=0.5,freqmax=5,corners=2)
dat4[0].data /= dat4[0].data.max()

dat5.filter('bandpass',freqmin=0.05,freqmax=0.5,corners=2)
dat5[0].data /= dat5[0].data.max()

dat6.filter('bandpass',freqmin=5.,freqmax=15.,corners=2)
dat6[0].data /= dat6[0].data.max()

#now plot them all in the same plot, with offsets (constants added to dat.data)
ax.plot(dat1[0].times('matplotlib'),dat1[0].data,'k-',linewidth=0.5)
ax.plot(dat2[0].times('matplotlib'),dat2[0].data + 1.5,'b-',linewidth=0.5)
ax.plot(dat3[0].times('matplotlib'),dat3[0].data + 3,'r-',linewidth=0.5)
ax.plot(dat4[0].times('matplotlib'),dat4[0].data + 4.5,'g-',linewidth=0.5)
ax.plot(dat5[0].times('matplotlib'),dat5[0].data + 6,'m-',linewidth=0.5)
ax.plot(dat6[0].times('matplotlib'),dat6[0].data + 7.5,'y-',linewidth=0.5)

#now write filters on the Y-Axis
yticks([0,1.5,3,4.5,6,7.5],['Raw','HP 1Hz','LP 1Hz','BP 0.5-5Hz','BP 0.05-0.5Hz','BP 5-15 Hz'])
#formatting of X-axis to show time
ax.xaxis_date()
fig.autofmt_xdate()
#write to file
if time_window == 1:
  savefig('test_filters1.pdf')
elif time_window == 2:
  savefig('test_filters2.pdf')

