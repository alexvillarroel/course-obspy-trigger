#!/usr/bin/env python

from obspy.core import read, UTCDateTime
from obspy.signal.trigger import recursive_sta_lta, trigger_onset
from obspy.clients.fdsn import Client

client1 = Client('iris')

t1 = UTCDateTime(2017,4,24,0,0,0)
t2 = UTCDateTime(2017,4,25,0,0,0)

#download in file
data = client1.get_waveforms('C1','VA05','--','HHZ',t1,t2)

#demean, bandpass filter
data.detrend(type='demean')
data.filter('bandpass',freqmax=5.,freqmin=1.,corners=2)

#apply STA/LTA with window lengths of 1.2 and 10 s
cft = recursive_sta_lta(data[0].data,120,1000)

#retrieve alert times for thresholds 5 (trigger) and 2.25 (detrigger)
on_off = trigger_onset(cft,5,2.25)
#open file for writing the output
outfile = open('Alerts.txt','w')

#loop over list of alerts
for j in on_off:
	on, off = j
	#translate times in samples to absolute times
	on_time = data[0].stats.starttime + (float(on) / data[0].stats.sampling_rate)
	off_time = data[0].stats.starttime + (float(off) / data[0].stats.sampling_rate)
	#output to file (string formatting)
	on_string = '%4i/%02i/%02i %02i:%02i:%05.2f' % (on_time.year,on_time.month,on_time.day,on_time.hour,on_time.minute,(on_time.second + (on_time.microsecond/1e6)))
	off_string = '%02i:%02i:%05.2f' % (off_time.hour,off_time.minute,(off_time.second + (off_time.microsecond/1e6)))

	outfile.write(data[0].stats.station+' '+on_string+' '+off_string+'\n')

#close output file
outfile.close()
